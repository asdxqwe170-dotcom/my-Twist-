import subprocess
import sys
import time
import os
import platform
from datetime import datetime
import re

def install_requirements():
    required = ['requests', 'colorama']
    for lib in required:
        try:
            __import__(lib)
        except ImportError:
            subprocess.check_call([sys.executable, "-m", "pip", "install", lib])
            time.sleep(1)

install_requirements()

import requests
import random
import string
import json
import uuid
import webbrowser
from colorama import init, Fore, Style

init(autoreset=True)

# ==================== CONFIGURATION ====================
MONTHLY_UNIT_LIMIT = 2000  # الحد الشهري للوحدات (2000 وحدة)
MAX_COLLECT_ATTEMPTS = 2   # عدد محاولات جمع النقاط
WEBSITE_URL = "https://music.twistmena.com/#/home/login"  # رابط الموقع
# =======================================================

def clear_screen():
    os.system('cls' if platform.system() == 'Windows' else 'clear')

def print_banner():
    clear_screen()
    print(f"{Fore.CYAN}{Style.BRIGHT}╔{'═' * 55}╗")
    print(f"{Fore.CYAN}{Style.BRIGHT}║  💰 TWIST - جمع النقاط والوحدات".center(57) + f"{Fore.CYAN}{Style.BRIGHT}║")
    print(f"{Fore.CYAN}{Style.BRIGHT}║  الحد الشهري: {MONTHLY_UNIT_LIMIT} وحدة".center(57) + f"{Fore.CYAN}{Style.BRIGHT}║")
    print(f"{Fore.CYAN}{Style.BRIGHT}║  حقوق kemo bey".center(57) + f"{Fore.CYAN}{Style.BRIGHT}║")
    print(f"{Fore.CYAN}{Style.BRIGHT}╚{'═' * 55}╝")
    print()

def show_main_menu():
    """يعرض القائمة الرئيسية وينفذ الخيار المطلوب مباشرة"""
    while True:
        print_banner()
        print(f"{Fore.CYAN}{Style.BRIGHT}╔{'═' * 55}╗")
        print(f"{Fore.CYAN}{Style.BRIGHT}║{Fore.WHITE}{Style.BRIGHT}القائمة الرئيسية".center(57) + f"{Fore.CYAN}{Style.BRIGHT}║")
        print(f"{Fore.CYAN}{Style.BRIGHT}╚{'═' * 55}╝")
        print(f"{Fore.WHITE}  [1] {Fore.GREEN}{Style.BRIGHT}الذهاب إلى الموقع")
        print(f"{Fore.WHITE}  [2] {Fore.CYAN}{Style.BRIGHT}معرفة الكوينز")
        print(f"{Fore.WHITE}  [3] {Fore.YELLOW}{Style.BRIGHT}الذهاب إلى السكريبت")
        print(f"{Fore.WHITE}  [0] {Fore.RED}خروج")
        print()

        choice = input(f"{Fore.YELLOW}📌 اختر: {Style.RESET_ALL}").strip()

        if choice == '1':
            display_progress("جاري فتح الموقع في المتصفح...")
            try:
                opened = webbrowser.open(WEBSITE_URL)
                if opened:
                    display_success("تم فتح الموقع بنجاح!\n")
                else:
                    raise RuntimeError("تعذر فتح المتصفح تلقائيًا")
            except Exception:
                display_warning("تعذر فتح المتصفح تلقائيًا، انسخ الرابط التالي وافتحه يدويًا:")
                print(f"{Fore.CYAN}{WEBSITE_URL}\n")
            input(f"{Fore.CYAN}اضغط Enter للعودة للقائمة...{Style.RESET_ALL}")
        elif choice == '2':
            check_coins_only()
            input(f"\n{Fore.CYAN}اضغط Enter للعودة للقائمة...{Style.RESET_ALL}")
        elif choice == '3':
            print_banner()
            run_bot()
            input(f"\n{Fore.CYAN}اضغط Enter للعودة للقائمة...{Style.RESET_ALL}")
        elif choice == '0':
            print(f"\n{Fore.CYAN}👋 تم الخروج!")
            sys.exit(0)
        else:
            display_error("اختيار غير صحيح! حاول مرة أخرى.\n")

def generate_session_id() -> str:
    return str(uuid.uuid4())

def get_base_headers() -> dict:
    return {
        "user-agent": "Twist-Mobile/9999 (Android; 12; SM-A217F; music; ar-AE)",
        "app_version": "9999",
        "appversion": "9999",
        "channel": "mobileapp",
        "content-type": "application/json",
        "platform": "android",
        "accept": "application/json",
        "accept-language": "ar",
        "host": "api.twistmena.com",
        "device_id": "SP1A.210812.016",
        "tgdeviceid": "26284330",
        "device_token": "",
        "tg-token": "",
        "tg-refresh-token": "",
        "access-token": "",
        "sessionid": generate_session_id(),
        "accept-encoding": "gzip",
        "connection": "keep-alive"
    }

def display_progress(message: str):
    print(f"{Fore.CYAN}● {Fore.WHITE}{message}")

def display_success(message: str):
    print(f"{Fore.GREEN}✓ {Fore.WHITE}{message}")

def display_error(message: str):
    print(f"{Fore.RED}✗ {Fore.WHITE}{message}")

def display_warning(message: str):
    print(f"{Fore.YELLOW}⚠ {Fore.WHITE}{message}")

def display_info(message: str):
    print(f"{Fore.MAGENTA}ℹ {Fore.WHITE}{message}")

def get_balance(headers: dict) -> int:
    """جلب الرصيد الحالي"""
    try:
        r = requests.get(
            'https://api.twistmena.com/music/user/loyalty/balance/details',
            headers=headers, timeout=10
        )
        if r.status_code == 200:
            data = r.json()
            return int(data.get('balance', 0))
        return 0
    except:
        return 0

def get_achievements(headers: dict) -> dict:
    """جلب المهام المتاحة"""
    try:
        r = requests.get(
            'https://api.twistmena.com/music/user/loyalty/achievements/v2',
            headers=headers, timeout=10
        )
        if r.status_code == 200:
            return r.json()
    except:
        pass
    return {}

def collect_all_actions(headers: dict) -> tuple:
    """تنفيذ جميع المهام المتاحة وجمع النقاط"""
    display_progress("جاري جلب المهام المتاحة...")
    data = get_achievements(headers)
    
    if not data:
        display_error("فشل في جلب المهام!")
        return 0, False
    
    all_actions = []
    
    badges = data.get('badges', [])
    if isinstance(badges, list):
        for category in badges:
            if isinstance(category, dict):
                tasks = category.get('badges', [])
                if isinstance(tasks, list):
                    for task in tasks:
                        if isinstance(task, dict):
                            task_id = task.get('id')
                            rewarded = task.get('rewarded', True)
                            coins = task.get('coins', 0)
                            title = task.get('title', task_id)
                            
                            if task_id and not rewarded:
                                all_actions.append({
                                    'id': task_id,
                                    'coins': coins,
                                    'title': title
                                })
    
    if not all_actions:
        display_warning("جميع المهام مكتملة!")
        return 0, False
    
    display_success(f"تم العثور على {len(all_actions)} مهمة\n")
    
    total_earned = 0
    completed = 0
    failed = 0
    has_error = False
    
    for i, action in enumerate(all_actions, 1):
        action_id = action['id']
        coins = action['coins']
        title = action['title']
        
        progress_text = f"[{i:02d}/{len(all_actions):02d}]"
        print(f"{Fore.WHITE}  {progress_text} {title[:35]:<35} {Fore.YELLOW}+{coins:>5} كوينز", end=" ")
        
        try:
            res = requests.post(
                f"https://api.twistmena.com/music/loyalty/action/{action_id}",
                headers=headers,
                timeout=8
            )
            if res.status_code == 200:
                total_earned += coins
                completed += 1
                print(f"{Fore.GREEN}  ✓ تم")
            elif res.status_code == 400:
                print(f"{Fore.YELLOW}  ⊘ مكتمل")
            elif res.status_code == 403:
                failed += 1
                has_error = True
                print(f"{Fore.RED}  ✗ ممنوع (403)")
                break
            else:
                failed += 1
                print(f"{Fore.RED}  ✗ فشل ({res.status_code})")
        except Exception as e:
            failed += 1
            has_error = True
            print(f"{Fore.RED}  ✗ خطأ: {str(e)[:30]}")
            break
        
        time.sleep(0.3)
    
    print(f"\n{Fore.CYAN}{'─' * 55}")
    if has_error:
        display_warning("⚠ لم يتم جمع المهام بنجاح!")
        display_error("❌ تأكد إنك داخل حسابك وسجلت على الموقع الرسمي أول قبل استخدام السكريبت.")
        print(f"{Fore.YELLOW}  👉 روح لخيار [1] الذهاب إلى الموقع وسجل / سجل دخول هناك الأول، وبعدين ارجع جرب تاني.")
    else:
        display_success(f"الملخص: {completed} مكتملة, {failed} فاشلة")
        display_success(f"إجمالي النقاط: +{total_earned}")
    print(f"{Fore.CYAN}{'─' * 55}")
    
    return total_earned, has_error

def get_all_history(headers: dict) -> list:
    """جلب جميع سجل المعاملات"""
    all_transactions = []
    pagination_token = ""
    
    while True:
        try:
            url = 'https://api.twistmena.com/music/user/loyalty/history'
            if pagination_token:
                url += f'?paginationToken={pagination_token}'
            
            r = requests.get(url, headers=headers, timeout=10)
            if r.status_code != 200:
                break
                
            data = r.json()
            transactions = data.get('data', [])
            if not transactions:
                break
                
            all_transactions.extend(transactions)
            pagination_token = data.get('paginationTokens', '')
            if not pagination_token:
                break
                
        except:
            break
    
    return all_transactions

def extract_units_from_description(description: str) -> int:
    """استخراج عدد الوحدات من وصف العملية"""
    patterns = [
        (r'(\\d+)\\s*وحدة\\s*e&', 1),
        (r'(\\d+)\\s*وحده\\s*e&', 1),
        (r'(\\d+)\\s*وحدة', 1),
        (r'(\\d+)\\s*وحده', 1),
        (r'(\\d+)\\s*Units?', 1),
        (r'(\\d+)\\s*وحدات', 1),
        (r'(\\d+)\\s*EAND', 1),
    ]
    
    for pattern, group in patterns:
        match = re.search(pattern, description)
        if match:
            return int(match.group(group))
    
    if 'خصم' in description or 'discount' in description.lower():
        return 0
    
    numbers = re.findall(r'\\d+', description)
    if numbers:
        num = int(numbers[0])
        if num >= 50:
            return num
    
    return 0

def calculate_monthly_units(transactions: list) -> int:
    """حساب الوحدات المسحوبة في الشهر الحالي"""
    now = datetime.now()
    current_month = now.month
    current_year = now.year
    
    total_units = 0
    
    for tx in transactions:
        if not isinstance(tx, dict):
            continue
            
        timestamp = tx.get('date', 0)
        if timestamp == 0:
            continue
            
        try:
            tx_date = datetime.fromtimestamp(timestamp / 1000)
        except:
            continue
        
        if tx_date.year == current_year and tx_date.month == current_month:
            direction = tx.get('direction', '')
            amount = tx.get('amount', 0)
            description = tx.get('description', '')
            
            if direction == 'DEBIT' and amount > 0:
                units = extract_units_from_description(description)
                if units > 0:
                    total_units += units
    
    return total_units

def get_packages(headers: dict) -> dict:
    """جلب قائمة الباقات المتاحة"""
    try:
        r = requests.get(
            'https://api.twistmena.com/music/user/loyalty/packages',
            headers=headers, timeout=10
        )
        if r.status_code == 200:
            return r.json()
    except:
        pass
    return {}

def build_redeem_options(packages_data: dict, balance: int, remaining_units: int) -> list:
    """بناء قائمة خيارات السحب"""
    options = []
    
    if remaining_units <= 0:
        return options
    
    if not packages_data:
        fallback = [
            (100, 50, "EAND_50_UNITS_ID_9"),
            (200, 100, "EAND_100_UNITS_ID_10"),
            (300, 150, "EAND_150_UNITS_ID_11"),
            (600, 300, "EAND_300_UNITS_ID_12"),
            (1000, 500, "EAND_500_UNITS_ID_13"),
            (2000, 1000, "EAND_1000_UNITS_ID_15"),
        ]
        for cost, units, code in fallback:
            if balance >= cost and units <= remaining_units:
                options.append((cost, units, code))
        return options
    
    e_and_packages = packages_data.get('packages', {}).get('E_AND', [])
    for pkg in e_and_packages:
        if isinstance(pkg, dict) and pkg.get('available', False):
            cost = pkg.get('cost', 0)
            units = pkg.get('value', 0)
            code = pkg.get('id', '')
            if balance >= cost and cost > 0 and units > 0 and units <= remaining_units:
                options.append((cost, units, code))
    
    return sorted(options, key=lambda x: x[0])

def redeem_units(headers: dict, redeem_code: str, units: int) -> bool:
    """تنفيذ عملية السحب"""
    try:
        res = requests.post(
            f"https://api.twistmena.com/music/loyalty/redeem/{redeem_code}",
            headers=headers, timeout=10
        )
        if res.status_code == 200:
            display_success(f"✓ تم السحب بنجاح! (+{units} وحدة)")
            return True
        else:
            display_error(f"✗ فشل السحب (HTTP: {res.status_code})")
            return False
    except Exception as e:
        display_error(f"✗ خطأ: {e}")
        return False

def get_profile_and_tokens(headers: dict, api_token: str) -> dict:
    """جلب معلومات الملف الشخصي"""
    tokens = {}
    try:
        r = requests.post(
            f"https://api.twistmena.com/music/register/getProfile?api_token={api_token}",
            headers=headers, timeout=10
        )
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, dict):
                tokens['tg-token'] = data.get('tgToken', data.get('tg_token', ''))
                tokens['tg-refresh-token'] = data.get('tgRefreshToken', data.get('tg_refresh_token', ''))
                tokens['tgdeviceid'] = data.get('tgDeviceId', data.get('tg_device_id', '26284330'))
    except:
        pass
    return tokens

def generate_api_token(n: int = 32) -> str:
    return ''.join(random.choice(string.hexdigits.lower()) for _ in range(n))

SESSION_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "twist_sessions.json")

def load_sessions() -> list:
    """يحمّل قائمة الجلسات المحفوظة من الملف"""
    if not os.path.exists(SESSION_FILE):
        return []
    try:
        with open(SESSION_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get('sessions', [])
    except Exception:
        return []

def save_sessions(sessions: list):
    """يحفظ قائمة الجلسات في الملف"""
    try:
        with open(SESSION_FILE, 'w', encoding='utf-8') as f:
            json.dump({'sessions': sessions}, f, ensure_ascii=False, indent=2)
    except Exception as e:
        display_warning(f"تعذر حفظ الجلسة: {e}")

def is_session_valid(headers: dict) -> bool:
    """يتحقق هل الجلسة المحفوظة لا تزال صالحة"""
    try:
        r = requests.get(
            'https://api.twistmena.com/music/user/loyalty/balance/details',
            headers=headers, timeout=10
        )
        return r.status_code == 200
    except Exception:
        return False
