"""
# ==============================================================
# @title: Twist Units Pro - تطبيق أندرويد متكامل (Kivy GUI)
# @author: kemo bey
# @theme: Modern Calm Dark (أسود ورصاصي ورمادي هادئ)
# ==============================================================
"""
import kivy
kivy.require('2.2.1')

import os
import json
import uuid
import time
import threading
import requests
import webbrowser
from datetime import datetime

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.progressbar import ProgressBar
from kivy.uix.popup import Popup
from kivy.core.window import Window
from kivy.clock import Clock

# ألوان التصميم الهادئ (Obsidian Black, Charcoal Slate, Calm Silver)
Window.clearcolor = (0.04, 0.05, 0.07, 1)

MONTHLY_UNIT_LIMIT = 2000
WEBSITE_URL = "https://music.twistmena.com/#/home/login"
SESSION_FILE = "twist_sessions.json"

class TwistMobileApp(App):
    def build(self):
        self.title = "Twist Units Pro"
        self.headers = self.get_base_headers()
        self.current_phone = ""
        self.balance = 0
        self.monthly_units = 0
        self.remaining_units = MONTHLY_UNIT_LIMIT
        self.is_farming = False

        # الحاوية الرئيسية
        root = BoxLayout(orientation='vertical', padding=12, spacing=10)

        # 1. شريط العنوان والترويسة (Header)
        header = BoxLayout(orientation='vertical', size_hint_y=None, height=75, padding=6)
        lbl_title = Label(
            text="[b]Twist Units Pro[/b]",
            markup=True,
            font_size='20sp',
            color=(0.95, 0.95, 0.98, 1)
        )
        lbl_sub = Label(
            text="حقوق kemo bey · واجهة أندرويد عصرية",
            font_size='12sp',
            color=(0.6, 0.65, 0.72, 1)
        )
        header.add_widget(lbl_title)
        header.add_widget(lbl_sub)
        root.add_widget(header)

        # 2. بطاقات الإحصائيات (الرصيد + الوحدات المتبقية)
        stats = GridLayout(cols=2, size_hint_y=None, height=95, spacing=8)
        
        card1 = BoxLayout(orientation='vertical', padding=6)
        self.lbl_coins = Label(
            text="[b]0[/b]\n[size=12]كوينز متاح[/size]",
            markup=True,
            font_size='18sp',
            color=(0.9, 0.9, 0.95, 1)
        )
        card1.add_widget(self.lbl_coins)
        stats.add_widget(card1)

        card2 = BoxLayout(orientation='vertical', padding=6)
        self.lbl_units = Label(
            text="[b]2,000[/b]\n[size=12]متبقي من الحد[/size]",
            markup=True,
            font_size='18sp',
            color=(0.7, 0.85, 0.75, 1)
        )
        card2.add_widget(self.lbl_units)
        stats.add_widget(card2)
        root.add_widget(stats)

        # 3. إدخال رقم الهاتف وتسجيل الدخول
        phone_box = BoxLayout(size_hint_y=None, height=45, spacing=8)
        self.phone_input = TextInput(
            hint_text='رقم الهاتف (مثال: 010xxxxxxxx)',
            multiline=False,
            font_size='13sp',
            background_color=(0.10, 0.12, 0.16, 1),
            foreground_color=(0.95, 0.95, 0.95, 1)
        )
        btn_login = Button(
            text='دخول OTP',
            size_hint_x=0.35,
            background_color=(0.18, 0.22, 0.28, 1),
            color=(1, 1, 1, 1),
            font_size='13sp'
        )
        btn_login.bind(on_press=self.on_login_click)
        phone_box.add_widget(self.phone_input)
        phone_box.add_widget(btn_login)
        root.add_widget(phone_box)

        # 4. شبكة الأزرار التفاعلية الرئيسية
        actions = GridLayout(cols=2, size_hint_y=None, height=110, spacing=8)

        btn_collect = Button(
            text='⚡ جمع النقاط تلقائياً',
            background_color=(0.16, 0.20, 0.26, 1),
            color=(1, 0.95, 0.8, 1),
            font_size='13sp'
        )
        btn_collect.bind(on_press=self.start_auto_farm)

        btn_balance = Button(
            text='💰 فحص الرصيد',
            background_color=(0.12, 0.15, 0.20, 1),
            color=(0.85, 0.9, 1, 1),
            font_size='13sp'
        )
        btn_balance.bind(on_press=self.start_check_balance)

        btn_redeem = Button(
            text='🎁 سحب الوحدات e&',
            background_color=(0.14, 0.18, 0.22, 1),
            color=(0.85, 1, 0.85, 1),
            font_size='13sp'
        )
        btn_redeem.bind(on_press=self.show_redeem_popup)

        btn_site = Button(
            text='🌐 موقع تويست',
            background_color=(0.10, 0.12, 0.16, 1),
            color=(0.8, 0.85, 0.9, 1),
            font_size='13sp'
        )
        btn_site.bind(on_press=lambda x: webbrowser.open(WEBSITE_URL))

        actions.add_widget(btn_collect)
        actions.add_widget(btn_balance)
        actions.add_widget(btn_redeem)
        actions.add_widget(btn_site)
        root.add_widget(actions)

        # 5. شريط التقدم
        self.progress = ProgressBar(max=100, value=0, size_hint_y=None, height=10)
        root.add_widget(self.progress)

        # 6. الطرفية وسجل العمليات
        scroll = ScrollView()
        self.log_label = Label(
            text="[color=888888]مرحباً بك! التطبيق جاهز للاستخدام.[/color]\n",
            markup=True,
            font_size='11sp',
            size_hint_y=None,
            halign='right',
            valign='top'
        )
        self.log_label.bind(texture_size=lambda instance, size: setattr(instance, 'height', size[1]))
        scroll.add_widget(self.log_label)
        root.add_widget(scroll)

        # محاولة تحميل الجلسة السابقة
        Clock.schedule_once(lambda dt: self.auto_load_last_session(), 0.5)

        return root

    def log(self, text, color="cccccc"):
        Clock.schedule_once(lambda dt: self._append_log(text, color))

    def _append_log(self, text, color):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_label.text += f"[color=666666][{ts}][/color] [color={color}]● {text}[/color]\n"

    def get_base_headers(self) -> dict:
        return {
            "user-agent": "Twist-Mobile/9999 (Android; 12; SM-A217F; music; ar-AE)",
            "app_version": "9999",
            "appversion": "9999",
            "channel": "mobileapp",
            "content-type": "application/json",
            "platform": "android",
            "accept": "application/json",
            "accept-language": "ar",
            "host": "api.twistmena.com",
            "device_id": "SP1A.210812.016",
            "tgdeviceid": "26284330",
            "device_token": "",
            "tg-token": "",
            "tg-refresh-token": "",
            "access-token": "",
            "sessionid": str(uuid.uuid4()),
            "connection": "keep-alive"
        }

    def auto_load_last_session(self):
        if not os.path.exists(SESSION_FILE):
            return
        try:
            with open(SESSION_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                sessions = data.get('sessions', [])
                if sessions:
                    last = sessions[-1]
                    self.current_phone = last.get('phone', '')
                    self.headers = last.get('headers', self.headers)
                    self.phone_input.text = self.current_phone
                    self.log(f"تم تحميل الجلسة المحفوظة لرقم: {self.current_phone}", "66ff99")
                    threading.Thread(target=self._fetch_balance_thread).start()
        except Exception as e:
            self.log(f"خطأ في قراءة الجلسات: {e}", "ff6666")

    def on_login_click(self, instance):
        phone = self.phone_input.text.strip()
        if not phone:
            self.log("يرجى إدخال رقم الهاتف أولاً!", "ff6666")
            return
        
        # تصحيح صيغة الرقم
        if phone.startswith("01"):
            clean_phone = "2" + phone
        elif phone.startswith("+2"):
            clean_phone = phone[1:]
        else:
            clean_phone = phone.replace("+", "").replace(" ", "")

        self.log(f"جاري إرسال رمز التحقق إلى: {clean_phone}...", "66ccff")
        threading.Thread(target=self._send_otp_thread, args=(clean_phone,)).start()

    def _send_otp_thread(self, phone):
        try:
            res = requests.post(
                "https://api.twistmena.com/music/Dlogin/sendCode",
                headers=self.headers,
                json={"dial": phone},
                timeout=10
            )
            if res.status_code == 200:
                self.log("تم إرسال رمز التحقق بنجاح! أدخل الرمز في النافذة المنبثقة.", "66ff99")
                Clock.schedule_once(lambda dt: self._show_otp_popup(phone))
            else:
                self.log(f"فشل إرسال الرمز: {res.text[:80]}", "ff6666")
        except Exception as e:
            self.log(f"خطأ في الاتصال: {e}", "ff6666")

    def _show_otp_popup(self, phone):
        box = BoxLayout(orientation='vertical', padding=10, spacing=10)
        lbl = Label(text=f"أدخل الرمز المرسل إلى\n{phone}", halign='center')
        otp_input = TextInput(hint_text='رمز التحقق (OTP)', multiline=False, font_size='16sp')
        btn_confirm = Button(text='تأكيد الرمز', background_color=(0.2, 0.7, 0.3, 1))

        box.add_widget(lbl)
        box.add_widget(otp_input)
        box.add_widget(btn_confirm)

        popup = Popup(title='التحقق من الهاتف', content=box, size_hint=(0.85, 0.4))

        def verify(inst):
            code = otp_input.text.strip()
            if code:
                popup.dismiss()
                threading.Thread(target=self._verify_otp_thread, args=(phone, code)).start()

        btn_confirm.bind(on_press=verify)
        popup.open()

    def _verify_otp_thread(self, phone, code):
        self.log("جاري التحقق من رمز OTP...", "66ccff")
        try:
            res = requests.post(
                "https://api.twistmena.com/music/Dlogin/verify",
                headers=self.headers,
                json={"dial": phone, "verifyCode": code, "socialServiceName": "", "socialServiceToken": ""},
                timeout=10
            )
            if res.status_code == 200:
                data = res.json()
                token = data.get('token') or data.get('authorization')
                if not token and res.headers.get('authorization'):
                    token = res.headers.get('authorization')
                
                clean_token = str(token).replace('Bearer ', '')
                self.headers['authorization'] = 'Bearer ' + clean_token
                self.current_phone = phone
                self.log("✓ تم تسجيل الدخول بنجاح!", "66ff99")

                # حفظ الجلسة
                self._save_session(phone, self.headers)
                self._fetch_balance_thread()
            else:
                self.log(f"رمز غير صحيح ({res.status_code})", "ff6666")
        except Exception as e:
            self.log(f"خطأ أثناء التحقق: {e}", "ff6666")

    def _save_session(self, phone, headers):
        try:
            sessions = []
            if os.path.exists(SESSION_FILE):
                with open(SESSION_FILE, 'r', encoding='utf-8') as f:
                    sessions = json.load(f).get('sessions', [])
            sessions = [s for s in sessions if s.get('phone') != phone]
            sessions.append({'phone': phone, 'headers': headers, 'last_used': datetime.now().isoformat()})
            with open(SESSION_FILE, 'w', encoding='utf-8') as f:
                json.dump({'sessions': sessions}, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def start_check_balance(self, instance):
        self.log("جاري الاستعلام عن الرصيد الحالي...", "66ccff")
        threading.Thread(target=self._fetch_balance_thread).start()

    def _fetch_balance_thread(self):
        try:
            r = requests.get(
                'https://api.twistmena.com/music/user/loyalty/balance/details',
                headers=self.headers,
                timeout=10
            )
            if r.status_code == 200:
                data = r.json()
                self.balance = int(data.get('balance', 0))
                Clock.schedule_once(lambda dt: self._update_ui_balance(self.balance))
                self.log(f"الرصيد الحالي: {self.balance:,} كوينز", "ffff66")
            else:
                self.log(f"تعذر جلب الرصيد (HTTP {r.status_code})", "ffaa66")
        except Exception as e:
            self.log(f"خطأ جلب الرصيد: {e}", "ff6666")

    def _update_ui_balance(self, bal):
        self.lbl_coins.text = f"[b]{bal:,}[/b]\n[size=12]كوينز متاح[/size]"

    def start_auto_farm(self, instance):
        if self.is_farming:
            self.log("الجمع قيد التشغيل بالفعل!", "ffff66")
            return
        self.is_farming = True
        self.progress.value = 0
        self.log("⚡ بدء جمع النقاط التلقائي لجميع المهام...", "ffff66")
        threading.Thread(target=self._farm_thread).start()

    def _farm_thread(self):
        try:
            # 1. جلب قائمة الإنجازات والمهام
            self.log("جاري جلب قائمة المهام من السيرفر...", "66ccff")
            r = requests.get('https://api.twistmena.com/music/user/loyalty/achievements/v2', headers=self.headers, timeout=10)
            if r.status_code != 200:
                self.log(f"فشل جلب المهام (HTTP {r.status_code})", "ff6666")
                self.is_farming = False
                return

            data = r.json()
            all_actions = []
            badges = data.get('badges', [])
            if isinstance(badges, list):
                for category in badges:
                    if isinstance(category, dict):
                        for task in category.get('badges', []):
                            if isinstance(task, dict) and not task.get('rewarded', True):
                                all_actions.append(task)

            if not all_actions:
                self.log("جميع المهام مكتملة مسبقاً! لا توجد كوينز جديدة حالياً.", "ffff66")
                self.is_farming = False
                return

            self.log(f"تم العثور على {len(all_actions)} مهمة متاحة للجمع!", "66ff99")
            total_earned = 0
            completed = 0

            for i, task in enumerate(all_actions, 1):
                task_id = task.get('id')
                coins = task.get('coins', 0)
                title = task.get('title', task_id)

                self.log(f"[{i}/{len(all_actions)}] جاري إتمام: {title[:30]} (+{coins} كوينز)...", "ffffff")
                try:
                    res = requests.post(f"https://api.twistmena.com/music/loyalty/action/{task_id}", headers=self.headers, timeout=8)
                    if res.status_code == 200:
                        total_earned += coins
                        completed += 1
                        self.log(f"  ✓ تم بنجاح! (+{coins})", "66ff99")
                    elif res.status_code == 403:
                        self.log("  ✗ خطأ 403 (يجب تسجيل الدخول أولاً في الموقع)", "ff6666")
                        break
                except Exception as e:
                    self.log(f"  ✗ خطأ: {e}", "ff6666")
                    break

                prog = int((i / len(all_actions)) * 100)
                Clock.schedule_once(lambda dt, p=prog: setattr(self.progress, 'value', p))
                time.sleep(0.4)

            self.log(f"🎉 اكتمل الجمع! تم إتمام {completed} مهمة وإضافة +{total_earned:,} كوينز.", "00ffcc")
            self._fetch_balance_thread()
        except Exception as e:
            self.log(f"خطأ أثناء الجمع: {e}", "ff6666")
        finally:
            self.is_farming = False

    def show_redeem_popup(self, instance):
        packages = [
            (100, 50, "EAND_50_UNITS_ID_9"),
            (200, 100, "EAND_100_UNITS_ID_10"),
            (300, 150, "EAND_150_UNITS_ID_11"),
            (600, 300, "EAND_300_UNITS_ID_12"),
            (1000, 500, "EAND_500_UNITS_ID_13"),
            (2000, 1000, "EAND_1000_UNITS_ID_15"),
        ]

        box = BoxLayout(orientation='vertical', padding=10, spacing=8)
        lbl = Label(text=f"اختر الباقة للسحب (رصيدك الحالي: {self.balance} كوينز):", size_hint_y=None, height=35)
        box.add_widget(lbl)

        scroll = ScrollView()
        grid = GridLayout(cols=1, spacing=6, size_hint_y=None)
        grid.bind(minimum_height=grid.setter('height'))

        popup = Popup(title='سحب باقات الوحدات e&', content=box, size_hint=(0.9, 0.75))

        for cost, units, code in packages:
            can_afford = self.balance >= cost
            btn = Button(
                text=f"{units} وحدة e&  ←  {cost} كوينز",
                size_hint_y=None,
                height=45,
                background_color=(0.18, 0.24, 0.20, 1) if can_afford else (0.12, 0.12, 0.14, 1),
                color=(1, 1, 1, 1) if can_afford else (0.5, 0.5, 0.5, 1)
            )

            def make_redeem_handler(c=cost, u=units, cd=code):
                def handler(inst):
                    popup.dismiss()
                    self.log(f"جاري سحب {u} وحدة مقابل {c} كوينز...", "ffff66")
                    threading.Thread(target=self._redeem_thread, args=(cd, u, c)).start()
                return handler

            if can_afford:
                btn.bind(on_press=make_redeem_handler(cost, units, code))
            grid.add_widget(btn)

        scroll.add_widget(grid)
        box.add_widget(scroll)
        popup.open()

    def _redeem_thread(self, code, units, cost):
        try:
            res = requests.post(f"https://api.twistmena.com/music/loyalty/redeem/{code}", headers=self.headers, timeout=10)
            if res.status_code == 200:
                self.log(f"✓ تم السحب بنجاح! تم إضافة {units} وحدة لرقمك.", "66ff99")
                self._fetch_balance_thread()
            else:
                self.log(f"✗ فشل السحب (HTTP {res.status_code})", "ff6666")
        except Exception as e:
            self.log(f"خطأ أثناء السحب: {e}", "ff6666")

if __name__ == '__main__':
    TwistMobileApp().run()
