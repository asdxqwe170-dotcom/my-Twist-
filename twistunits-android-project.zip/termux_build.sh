#!/data/data/com.termux/files/usr/bin/bash
# ==========================================
# سكريبت تجميع وتثبيت على الهاتف مباشرة (Termux)
# ==========================================
echo "=========================================="
echo "  بدء إعداد بيئة بايثون للأندرويد..."
echo "=========================================="

pkg update -y && pkg upgrade -y
pkg install -y python git libffi openssl clang make

pip install --upgrade pip
pip install requests colorama

echo "=========================================="
echo "  لتشغيل السكريبت الآن مباشرة على الهاتف:"
echo "  python twist_cli.py"
echo "=========================================="
